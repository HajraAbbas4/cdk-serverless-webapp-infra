#!/usr/bin/env python3
"""
app.py
------
CDK application entry point.

Responsibilities:
  1. Load deployment configuration from environment variables (account,
     region, project name, environment name).
  2. Instantiate each modular stack in dependency order:
       NetworkStack -> StorageStack -> ComputeStack -> ApiStack -> MonitoringStack
  3. Wire the outputs of earlier stacks (VPC, security groups, bucket,
     table, Lambda function, REST API) into the stacks that depend on them.

Run `cdk synth`, `cdk diff`, or `cdk deploy` from this directory to operate
on the app defined here (see cdk.json's "app" entry).
"""

import os

import aws_cdk as cdk

from stacks.network_stack import NetworkStack
from stacks.storage_stack import StorageStack
from stacks.compute_stack import ComputeStack
from stacks.api_stack import ApiStack
from stacks.monitoring_stack import MonitoringStack


def main() -> None:
    app = cdk.App()

    # ------------------------------------------------------------------
    # Deployment configuration, sourced from environment variables with
    # sane fallbacks. Set these before running `cdk deploy`, e.g.:
    #
    #   export CDK_DEFAULT_ACCOUNT=123456789012
    #   export CDK_DEFAULT_REGION=us-east-1
    #   export PROJECT_NAME=iac-webapp
    #   export DEPLOY_ENV=dev
    # ------------------------------------------------------------------
    account = os.getenv("CDK_DEFAULT_ACCOUNT")
    region = os.getenv("CDK_DEFAULT_REGION", "us-east-1")
    project_name = os.getenv("PROJECT_NAME", "iac-webapp")
    environment = os.getenv("DEPLOY_ENV", "dev")

    env = cdk.Environment(account=account, region=region)

    # A common stack-naming prefix keeps related stacks grouped together
    # in the CloudFormation console.
    prefix = f"{project_name}-{environment}"

    try:
        # 1. Networking foundation: VPC, subnets, security groups.
        network_stack = NetworkStack(
            app,
            f"{prefix}-NetworkStack",
            env=env,
            description="VPC, subnets, and security groups for the "
            "application environment.",
        )

        # 2. Data storage: S3 bucket and DynamoDB table.
        storage_stack = StorageStack(
            app,
            f"{prefix}-StorageStack",
            env=env,
            description="S3 bucket and DynamoDB table for application data.",
        )

        # 3. Compute: Lambda function + least-privilege IAM role, deployed
        #    into the private subnets created by NetworkStack and granted
        #    scoped access to the storage resources.
        compute_stack = ComputeStack(
            app,
            f"{prefix}-ComputeStack",
            vpc=network_stack.vpc,
            lambda_security_group=network_stack.lambda_security_group,
            app_bucket=storage_stack.app_bucket,
            app_table=storage_stack.app_table,
            env=env,
            description="Lambda function, IAM role, and log group for "
            "application business logic.",
        )
        # Explicit dependency: ensures NetworkStack/StorageStack fully
        # deploy before ComputeStack attempts to reference their resources.
        compute_stack.add_dependency(network_stack)
        compute_stack.add_dependency(storage_stack)

        # 4. API layer: API Gateway REST API in front of the Lambda function.
        api_stack = ApiStack(
            app,
            f"{prefix}-ApiStack",
            handler_function=compute_stack.handler_function,
            env=env,
            description="API Gateway REST API connected to the application "
            "Lambda function.",
        )
        api_stack.add_dependency(compute_stack)

        # 5. Monitoring: CloudWatch Dashboard summarizing the stacks above.
        monitoring_stack = MonitoringStack(
            app,
            f"{prefix}-MonitoringStack",
            handler_function=compute_stack.handler_function,
            api=api_stack.api,
            app_table=storage_stack.app_table,
            env=env,
            description="CloudWatch Dashboard for monitoring the "
            "application's health.",
        )
        monitoring_stack.add_dependency(api_stack)

    except Exception as exc:
        # Fail fast with a clear message if stack construction itself
        # raises an error (e.g. missing required configuration), rather
        # than letting CDK produce a less obvious stack trace.
        print(f"ERROR: Failed to build CDK application: {exc}")
        raise

    app.synth()


if __name__ == "__main__":
    main()
