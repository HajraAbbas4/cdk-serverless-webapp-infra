"""
compute_stack.py
-----------------
Defines the compute layer of the application:
  - A single AWS Lambda function (Python 3.12) that implements the
    application's business logic and talks to DynamoDB and S3.
  - A dedicated IAM execution role, granted only the specific, least-
    privilege permissions the function needs (no wildcard "*" actions).
  - A CloudWatch Log Group with an explicit retention period so logs don't
    accumulate (and cost money) forever.

The function is deployed inside the private subnets of the VPC created by
NetworkStack so that it can be placed under network-level controls (security
groups / future NACLs) while still reaching AWS services via NAT Gateway.
"""

import os

from aws_cdk import (
    Stack,
    Tags,
    Duration,
    RemovalPolicy,
    aws_lambda as _lambda,
    aws_iam as iam,
    aws_logs as logs,
    aws_ec2 as ec2,
    aws_s3 as s3,
    aws_dynamodb as dynamodb,
)
from constructs import Construct


class ComputeStack(Stack):
    """Creates the Lambda function, its IAM role, and its log group."""

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        vpc: ec2.Vpc,
        lambda_security_group: ec2.SecurityGroup,
        app_bucket: s3.Bucket,
        app_table: dynamodb.Table,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        project_name = os.getenv("PROJECT_NAME", "iac-webapp")
        environment = os.getenv("DEPLOY_ENV", "dev")
        log_retention_days = int(os.getenv("LOG_RETENTION_DAYS", "14"))

        # ------------------------------------------------------------------
        # CloudWatch Log Group (created explicitly so we control retention
        # and naming, rather than letting Lambda create one implicitly with
        # infinite retention).
        # ------------------------------------------------------------------
        self.log_group = logs.LogGroup(
            self,
            "LambdaLogGroup",
            log_group_name=f"/aws/lambda/{project_name}-{environment}-handler",
            retention=logs.RetentionDays(log_retention_days)
            if log_retention_days in [r.value for r in logs.RetentionDays]
            else logs.RetentionDays.TWO_WEEKS,
            removal_policy=RemovalPolicy.DESTROY,
        )

        # ------------------------------------------------------------------
        # IAM Role - least privilege execution role for the Lambda function
        # ------------------------------------------------------------------
        self.lambda_role = iam.Role(
            self,
            "LambdaExecutionRole",
            role_name=f"{project_name}-{environment}-lambda-role",
            assumed_by=iam.ServicePrincipal("lambda.amazonaws.com"),
            description="Least-privilege execution role for the application "
            "Lambda function.",
        )

        # Managed policy required for a Lambda function running inside a VPC
        # (to create/manage the elastic network interfaces used to reach
        # private subnets).
        self.lambda_role.add_managed_policy(
            iam.ManagedPolicy.from_aws_managed_policy_name(
                "service-role/AWSLambdaVPCAccessExecutionRole"
            )
        )

        # Explicit, scoped permission to write logs to ONLY this function's
        # log group (rather than the broad AWSLambdaBasicExecutionRole,
        # which grants CreateLogGroup on all resources).
        self.log_group.grant_write(self.lambda_role)

        # Grant scoped read/write access to the DynamoDB table (grant_*
        # helpers automatically restrict the resource ARN to this table and
        # its indexes only).
        app_table.grant_read_write_data(self.lambda_role)

        # Grant scoped read/write access to the S3 bucket (restricted to
        # this bucket and its objects only).
        app_bucket.grant_read_write(self.lambda_role)

        # ------------------------------------------------------------------
        # Lambda Function
        # ------------------------------------------------------------------
        self.handler_function = _lambda.Function(
            self,
            "ApplicationHandler",
            function_name=f"{project_name}-{environment}-handler",
            runtime=_lambda.Runtime.PYTHON_3_12,
            handler="handler.lambda_handler",
            code=_lambda.Code.from_asset("lambda"),
            role=self.lambda_role,
            timeout=Duration.seconds(10),
            memory_size=256,
            # Deploy into the private (egress) subnets created by
            # NetworkStack so the function is not internet-facing.
            vpc=vpc,
            vpc_subnets=ec2.SubnetSelection(
                subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS
            ),
            security_groups=[lambda_security_group],
            # Environment variables give the function the resource names it
            # needs at runtime without hardcoding them in source code.
            environment={
                "TABLE_NAME": app_table.table_name,
                "BUCKET_NAME": app_bucket.bucket_name,
                "ENVIRONMENT": environment,
                "LOG_LEVEL": os.getenv("LAMBDA_LOG_LEVEL", "INFO"),
            },
            # Reuse the log group we created explicitly above.
            log_group=self.log_group,
            description="Application business-logic handler invoked via "
            "API Gateway.",
        )

        # ------------------------------------------------------------------
        # Tagging
        # ------------------------------------------------------------------
        Tags.of(self).add("Project", project_name)
        Tags.of(self).add("Environment", environment)
        Tags.of(self).add("Stack", "ComputeStack")
