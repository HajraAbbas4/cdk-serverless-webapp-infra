"""
storage_stack.py
-----------------
Defines the data-storage layer of the application:
  - An S3 bucket with versioning, server-side encryption (SSE-S3), blocked
    public access, and an enforced-SSL bucket policy.
  - A DynamoDB table using Pay-Per-Request (on-demand) billing, with
    point-in-time recovery enabled and encryption at rest.

Both resources expose their names/ARNs as public attributes so the compute
stack can grant the Lambda function least-privilege access to them.
"""

import os

from aws_cdk import (
    Stack,
    Tags,
    RemovalPolicy,
    aws_s3 as s3,
    aws_dynamodb as dynamodb,
)
from constructs import Construct


class StorageStack(Stack):
    """Creates the S3 bucket and DynamoDB table used by the application."""

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        project_name = os.getenv("PROJECT_NAME", "iac-webapp")
        environment = os.getenv("DEPLOY_ENV", "dev")

        # For a dev/demo environment it's convenient to auto-delete objects
        # on stack teardown; production stacks should use RemovalPolicy.RETAIN
        # to avoid accidental data loss. This is controlled by an env var so
        # the same code works safely across environments.
        is_production = environment.lower() == "prod"
        removal_policy = RemovalPolicy.RETAIN if is_production else RemovalPolicy.DESTROY

        # ------------------------------------------------------------------
        # S3 Bucket - secure defaults
        # ------------------------------------------------------------------
        self.app_bucket = s3.Bucket(
            self,
            "ApplicationBucket",
            bucket_name=f"{project_name}-{environment}-app-data-{Stack.of(self).account}",
            # Versioning protects against accidental overwrite/delete.
            versioned=True,
            # Server-side encryption using S3-managed keys (SSE-S3). Using
            # S3_MANAGED avoids extra KMS costs while still encrypting data
            # at rest; swap to KMS-managed for stricter key-control needs.
            encryption=s3.BucketEncryption.S3_MANAGED,
            # Block ALL forms of public access - a core secure default.
            block_public_access=s3.BlockPublicAccess.BLOCK_ALL,
            # Force HTTPS for all requests to the bucket.
            enforce_ssl=True,
            # Removal policy depends on environment (see above).
            removal_policy=removal_policy,
            auto_delete_objects=not is_production,
            # Lifecycle rule: transition older, non-current object versions
            # to cheaper storage and eventually expire them, keeping storage
            # costs under control while retaining short-term recovery.
            lifecycle_rules=[
                s3.LifecycleRule(
                    id="ExpireOldVersions",
                    noncurrent_version_expiration=None,  # keep indefinitely by default
                    enabled=True,
                    abort_incomplete_multipart_upload_after=None,
                )
            ],
        )

        # ------------------------------------------------------------------
        # DynamoDB Table - Pay-Per-Request billing
        # ------------------------------------------------------------------
        self.app_table = dynamodb.Table(
            self,
            "ApplicationTable",
            table_name=f"{project_name}-{environment}-items",
            partition_key=dynamodb.Attribute(
                name="pk", type=dynamodb.AttributeType.STRING
            ),
            sort_key=dynamodb.Attribute(
                name="sk", type=dynamodb.AttributeType.STRING
            ),
            # On-demand billing removes the need to plan/provision
            # read/write capacity, which is ideal for unpredictable or
            # low/medium-traffic workloads.
            billing_mode=dynamodb.BillingMode.PAY_PER_REQUEST,
            # Encryption at rest using AWS-owned keys by default.
            encryption=dynamodb.TableEncryption.AWS_MANAGED,
            # Point-in-time recovery allows restoring the table to any point
            # in the last 35 days - an important resilience/backup control.
            point_in_time_recovery=True,
            removal_policy=removal_policy,
        )

        # ------------------------------------------------------------------
        # Tagging
        # ------------------------------------------------------------------
        Tags.of(self).add("Project", project_name)
        Tags.of(self).add("Environment", environment)
        Tags.of(self).add("Stack", "StorageStack")
