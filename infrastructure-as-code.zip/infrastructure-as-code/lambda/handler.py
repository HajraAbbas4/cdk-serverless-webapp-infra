"""
handler.py
----------
AWS Lambda handler invoked by API Gateway (Lambda proxy integration).

Supported routes:
  GET  /items        -> list up to 20 items from DynamoDB
  GET  /items/{id}    -> fetch a single item by id
  POST /items        -> create a new item in DynamoDB

Environment variables (set by ComputeStack):
  TABLE_NAME   - name of the DynamoDB table to read/write.
  BUCKET_NAME  - name of the S3 bucket available for object storage.
  ENVIRONMENT  - deployment environment name (dev/stage/prod).
  LOG_LEVEL    - Python logging level (default INFO).

This handler uses only the Python standard library plus boto3 (which is
included in the standard AWS Lambda Python 3.12 runtime), so no extra
dependencies need to be bundled.
"""

import json
import logging
import os
import time
import uuid
from typing import Any, Dict

import boto3
from botocore.exceptions import ClientError

# ---------------------------------------------------------------------------
# Logging setup
# ---------------------------------------------------------------------------
logger = logging.getLogger()
logger.setLevel(os.getenv("LOG_LEVEL", "INFO"))

# ---------------------------------------------------------------------------
# AWS clients / resources (initialized once per execution environment for
# performance - reused across warm invocations).
# ---------------------------------------------------------------------------
TABLE_NAME = os.environ.get("TABLE_NAME")
BUCKET_NAME = os.environ.get("BUCKET_NAME")

dynamodb_resource = boto3.resource("dynamodb")
table = dynamodb_resource.Table(TABLE_NAME) if TABLE_NAME else None


def _response(status_code: int, body: Dict[str, Any]) -> Dict[str, Any]:
    """Builds a well-formed API Gateway proxy-integration response."""
    return {
        "statusCode": status_code,
        "headers": {
            "Content-Type": "application/json",
            "Access-Control-Allow-Origin": "*",
        },
        "body": json.dumps(body),
    }


def _list_items() -> Dict[str, Any]:
    """Scans the table for up to 20 items. (A Scan is used here for
    simplicity; a production workload would use a Query against a known
    partition key or a Global Secondary Index instead.)"""
    try:
        result = table.scan(Limit=20)
        return _response(200, {"items": result.get("Items", [])})
    except ClientError as err:
        logger.error("DynamoDB scan failed: %s", err)
        return _response(500, {"message": "Failed to list items."})


def _get_item(item_id: str) -> Dict[str, Any]:
    """Fetches a single item by its id (used as both pk and sk)."""
    try:
        result = table.get_item(Key={"pk": item_id, "sk": item_id})
        item = result.get("Item")
        if not item:
            return _response(404, {"message": f"Item '{item_id}' not found."})
        return _response(200, {"item": item})
    except ClientError as err:
        logger.error("DynamoDB get_item failed: %s", err)
        return _response(500, {"message": "Failed to fetch item."})


def _create_item(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Creates a new item in DynamoDB using a generated UUID as the key."""
    item_id = str(uuid.uuid4())
    item = {
        "pk": item_id,
        "sk": item_id,
        "created_at": int(time.time()),
        "data": payload,
    }
    try:
        table.put_item(Item=item)
        return _response(201, {"message": "Item created.", "item": item})
    except ClientError as err:
        logger.error("DynamoDB put_item failed: %s", err)
        return _response(500, {"message": "Failed to create item."})


def lambda_handler(event: Dict[str, Any], context: Any) -> Dict[str, Any]:
    """
    Main Lambda entry point. Routes the incoming API Gateway proxy event to
    the appropriate handler function based on HTTP method and path, with
    defensive exception handling around the whole request lifecycle.
    """
    try:
        http_method = event.get("httpMethod", "GET")
        path_parameters = event.get("pathParameters") or {}
        item_id = path_parameters.get("id")

        logger.info("Handling %s request (item_id=%s)", http_method, item_id)

        if not table:
            # Configuration error - the function was deployed without the
            # required TABLE_NAME environment variable.
            logger.error("TABLE_NAME environment variable is not set.")
            return _response(500, {"message": "Server misconfiguration."})

        if http_method == "GET" and item_id:
            return _get_item(item_id)

        if http_method == "GET":
            return _list_items()

        if http_method == "POST":
            raw_body = event.get("body") or "{}"
            try:
                payload = json.loads(raw_body)
            except json.JSONDecodeError:
                return _response(400, {"message": "Request body must be valid JSON."})
            return _create_item(payload)

        return _response(405, {"message": f"Method '{http_method}' not allowed."})

    except Exception as exc:  # noqa: BLE001 - top-level catch-all is intentional
        # Catch-all handler: ensures the function never crashes with an
        # unhandled exception (which would surface as an opaque 502 from
        # API Gateway) and instead returns a clean, logged 500 response.
        logger.exception("Unhandled error processing request: %s", exc)
        return _response(500, {"message": "Internal server error."})
