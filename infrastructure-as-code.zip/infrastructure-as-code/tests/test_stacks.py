"""
test_stacks.py
---------------
CDK assertion tests using pytest + aws_cdk.assertions.

These tests synthesize each stack in isolation (or in the required
combination) and assert that key resources are present with expected
properties. Run with:

    pytest tests/ -v

or simply:

    pytest
"""

import os

import aws_cdk as cdk
from aws_cdk.assertions import Template, Match
import pytest

from stacks.network_stack import NetworkStack
from stacks.storage_stack import StorageStack
from stacks.compute_stack import ComputeStack
from stacks.api_stack import ApiStack
from stacks.monitoring_stack import MonitoringStack

# Use a fixed test account/region so synthesis is deterministic in CI.
TEST_ENV = cdk.Environment(account="123456789012", region="us-east-1")


@pytest.fixture(scope="module")
def app() -> cdk.App:
    return cdk.App()


# All stacks share a single App and must be constructed together, BEFORE any
# Template.from_stack() call triggers synthesis. CDK synthesizes the whole
# app tree at once; if a stack is added to the app *after* an earlier
# Template.from_stack() call has already triggered synthesis, the assembly
# will not contain it. Building every stack up-front in one module-scoped
# fixture avoids that ordering pitfall.
@pytest.fixture(scope="module")
def all_stacks(app: cdk.App):
    network_stack = NetworkStack(app, "TestNetworkStack", env=TEST_ENV)
    storage_stack = StorageStack(app, "TestStorageStack", env=TEST_ENV)
    compute_stack = ComputeStack(
        app,
        "TestComputeStack",
        vpc=network_stack.vpc,
        lambda_security_group=network_stack.lambda_security_group,
        app_bucket=storage_stack.app_bucket,
        app_table=storage_stack.app_table,
        env=TEST_ENV,
    )
    api_stack = ApiStack(
        app,
        "TestApiStack",
        handler_function=compute_stack.handler_function,
        env=TEST_ENV,
    )
    monitoring_stack = MonitoringStack(
        app,
        "TestMonitoringStack",
        handler_function=compute_stack.handler_function,
        api=api_stack.api,
        app_table=storage_stack.app_table,
        env=TEST_ENV,
    )
    return {
        "network": network_stack,
        "storage": storage_stack,
        "compute": compute_stack,
        "api": api_stack,
        "monitoring": monitoring_stack,
    }


@pytest.fixture(scope="module")
def network_stack(all_stacks) -> NetworkStack:
    return all_stacks["network"]


@pytest.fixture(scope="module")
def storage_stack(all_stacks) -> StorageStack:
    return all_stacks["storage"]


@pytest.fixture(scope="module")
def compute_stack(all_stacks) -> ComputeStack:
    return all_stacks["compute"]


@pytest.fixture(scope="module")
def api_stack(all_stacks) -> ApiStack:
    return all_stacks["api"]


@pytest.fixture(scope="module")
def monitoring_stack(all_stacks) -> MonitoringStack:
    return all_stacks["monitoring"]


# ---------------------------------------------------------------------------
# NetworkStack tests
# ---------------------------------------------------------------------------
class TestNetworkStack:
    def test_vpc_created(self, network_stack: NetworkStack):
        template = Template.from_stack(network_stack)
        template.resource_count_is("AWS::EC2::VPC", 1)

    def test_public_and_private_subnets_created(self, network_stack: NetworkStack):
        template = Template.from_stack(network_stack)
        # 2 AZs * 2 subnet types (Public, PrivateApp) = 4 subnets.
        template.resource_count_is("AWS::EC2::Subnet", 4)

    def test_nat_gateway_created(self, network_stack: NetworkStack):
        template = Template.from_stack(network_stack)
        template.resource_count_is("AWS::EC2::NatGateway", 1)

    def test_internet_gateway_created(self, network_stack: NetworkStack):
        template = Template.from_stack(network_stack)
        template.resource_count_is("AWS::EC2::InternetGateway", 1)

    def test_lambda_security_group_has_no_open_ingress(
        self, network_stack: NetworkStack
    ):
        template = Template.from_stack(network_stack)
        # The Lambda security group should not define any SecurityGroupIngress
        # rules (no inbound access needed).
        template.has_resource_properties(
            "AWS::EC2::SecurityGroup",
            {
                "GroupDescription": Match.string_like_regexp(
                    "Security group for application Lambda functions.*"
                ),
            },
        )


# ---------------------------------------------------------------------------
# StorageStack tests
# ---------------------------------------------------------------------------
class TestStorageStack:
    def test_s3_bucket_has_versioning_and_encryption(
        self, storage_stack: StorageStack
    ):
        template = Template.from_stack(storage_stack)
        template.has_resource_properties(
            "AWS::S3::Bucket",
            {
                "VersioningConfiguration": {"Status": "Enabled"},
                "BucketEncryption": {
                    "ServerSideEncryptionConfiguration": Match.array_with(
                        [
                            Match.object_like(
                                {
                                    "ServerSideEncryptionByDefault": {
                                        "SSEAlgorithm": "AES256"
                                    }
                                }
                            )
                        ]
                    )
                },
            },
        )

    def test_s3_bucket_blocks_public_access(self, storage_stack: StorageStack):
        template = Template.from_stack(storage_stack)
        template.has_resource_properties(
            "AWS::S3::Bucket",
            {
                "PublicAccessBlockConfiguration": {
                    "BlockPublicAcls": True,
                    "BlockPublicPolicy": True,
                    "IgnorePublicAcls": True,
                    "RestrictPublicBuckets": True,
                }
            },
        )

    def test_dynamodb_table_uses_pay_per_request_billing(
        self, storage_stack: StorageStack
    ):
        template = Template.from_stack(storage_stack)
        template.has_resource_properties(
            "AWS::DynamoDB::Table",
            {
                "BillingMode": "PAY_PER_REQUEST",
                "PointInTimeRecoverySpecification": {
                    "PointInTimeRecoveryEnabled": True
                },
            },
        )


# ---------------------------------------------------------------------------
# ComputeStack tests
# ---------------------------------------------------------------------------
class TestComputeStack:
    def test_lambda_function_uses_python312(self, compute_stack: ComputeStack):
        template = Template.from_stack(compute_stack)
        template.has_resource_properties(
            "AWS::Lambda::Function",
            {
                "Runtime": "python3.12",
                "Handler": "handler.lambda_handler",
            },
        )

    def test_log_group_has_retention_set(self, compute_stack: ComputeStack):
        template = Template.from_stack(compute_stack)
        template.has_resource_properties(
            "AWS::Logs::LogGroup",
            {"RetentionInDays": 14},
        )

    def test_iam_role_created_for_lambda(self, compute_stack: ComputeStack):
        template = Template.from_stack(compute_stack)
        template.has_resource_properties(
            "AWS::IAM::Role",
            {
                "AssumeRolePolicyDocument": {
                    "Statement": Match.array_with(
                        [
                            Match.object_like(
                                {
                                    "Principal": {
                                        "Service": "lambda.amazonaws.com"
                                    }
                                }
                            )
                        ]
                    )
                }
            },
        )


# ---------------------------------------------------------------------------
# ApiStack tests
# ---------------------------------------------------------------------------
class TestApiStack:
    def test_rest_api_created(self, api_stack: ApiStack):
        template = Template.from_stack(api_stack)
        template.resource_count_is("AWS::ApiGateway::RestApi", 1)

    def test_items_methods_created(self, api_stack: ApiStack):
        template = Template.from_stack(api_stack)
        # GET+POST on /items, GET on /items/{id}, plus an auto-generated
        # OPTIONS (CORS preflight) method on each of the 3 resources
        # (root is not counted): 3 explicit + 3 OPTIONS = 6.
        template.resource_count_is("AWS::ApiGateway::Method", 6)


# ---------------------------------------------------------------------------
# MonitoringStack tests
# ---------------------------------------------------------------------------
class TestMonitoringStack:
    def test_dashboard_created(self, monitoring_stack: MonitoringStack):
        template = Template.from_stack(monitoring_stack)
        template.resource_count_is("AWS::CloudWatch::Dashboard", 1)
