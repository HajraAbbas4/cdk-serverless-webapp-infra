"""
monitoring_stack.py
--------------------
Defines the observability layer of the application:
  - A CloudWatch Dashboard that visualizes key metrics across the Lambda
    function, API Gateway, and DynamoDB table, giving a single pane of
    glass for operational health.

This stack is intentionally created last so it can reference the concrete
resources (Lambda function, REST API, DynamoDB table) produced by the other
stacks.
"""

import os

from aws_cdk import (
    Stack,
    Tags,
    Duration,
    aws_cloudwatch as cloudwatch,
    aws_lambda as _lambda,
    aws_apigateway as apigw,
    aws_dynamodb as dynamodb,
)
from constructs import Construct


class MonitoringStack(Stack):
    """Creates a CloudWatch Dashboard summarizing application health."""

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        handler_function: _lambda.Function,
        api: apigw.RestApi,
        app_table: dynamodb.Table,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        project_name = os.getenv("PROJECT_NAME", "iac-webapp")
        environment = os.getenv("DEPLOY_ENV", "dev")

        dashboard = cloudwatch.Dashboard(
            self,
            "ApplicationDashboard",
            dashboard_name=f"{project_name}-{environment}-dashboard",
        )

        # ------------------------------------------------------------------
        # Lambda widgets: invocations, errors, duration, throttles
        # ------------------------------------------------------------------
        lambda_invocations = handler_function.metric_invocations(
            period=Duration.minutes(5)
        )
        lambda_errors = handler_function.metric_errors(period=Duration.minutes(5))
        lambda_duration = handler_function.metric_duration(period=Duration.minutes(5))
        lambda_throttles = handler_function.metric_throttles(
            period=Duration.minutes(5)
        )

        dashboard.add_widgets(
            cloudwatch.GraphWidget(
                title="Lambda Invocations & Errors",
                left=[lambda_invocations],
                right=[lambda_errors],
                width=12,
            ),
            cloudwatch.GraphWidget(
                title="Lambda Duration (ms)",
                left=[lambda_duration],
                width=12,
            ),
        )

        dashboard.add_widgets(
            cloudwatch.GraphWidget(
                title="Lambda Throttles",
                left=[lambda_throttles],
                width=12,
            ),
        )

        # ------------------------------------------------------------------
        # API Gateway widgets: request count, 4xx/5xx errors, latency
        # ------------------------------------------------------------------
        api_requests = api.metric_count(period=Duration.minutes(5))
        api_4xx = api.metric_client_error(period=Duration.minutes(5))
        api_5xx = api.metric_server_error(period=Duration.minutes(5))
        api_latency = api.metric_latency(period=Duration.minutes(5))

        dashboard.add_widgets(
            cloudwatch.GraphWidget(
                title="API Gateway Requests",
                left=[api_requests],
                width=12,
            ),
            cloudwatch.GraphWidget(
                title="API Gateway 4xx / 5xx Errors",
                left=[api_4xx, api_5xx],
                width=12,
            ),
        )

        dashboard.add_widgets(
            cloudwatch.GraphWidget(
                title="API Gateway Latency (ms)",
                left=[api_latency],
                width=12,
            ),
        )

        # ------------------------------------------------------------------
        # DynamoDB widgets: consumed read/write capacity, throttled requests
        # ------------------------------------------------------------------
        dynamo_read = app_table.metric_consumed_read_capacity_units(
            period=Duration.minutes(5)
        )
        dynamo_write = app_table.metric_consumed_write_capacity_units(
            period=Duration.minutes(5)
        )
        dynamo_throttles = app_table.metric_throttled_requests_for_operations(
            operations=[dynamodb.Operation.GET_ITEM, dynamodb.Operation.PUT_ITEM],
            period=Duration.minutes(5),
        )

        dashboard.add_widgets(
            cloudwatch.GraphWidget(
                title="DynamoDB Consumed Capacity (Read/Write)",
                left=[dynamo_read],
                right=[dynamo_write],
                width=12,
            ),
            cloudwatch.GraphWidget(
                title="DynamoDB Throttled Requests",
                left=[dynamo_throttles],
                width=12,
            ),
        )

        self.dashboard = dashboard

        # ------------------------------------------------------------------
        # Tagging
        # ------------------------------------------------------------------
        Tags.of(self).add("Project", project_name)
        Tags.of(self).add("Environment", environment)
        Tags.of(self).add("Stack", "MonitoringStack")
