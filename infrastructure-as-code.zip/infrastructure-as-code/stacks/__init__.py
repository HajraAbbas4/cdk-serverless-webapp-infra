# Marks the `stacks` directory as a Python package.
