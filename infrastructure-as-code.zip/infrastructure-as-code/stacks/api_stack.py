"""
api_stack.py
-------------
Defines the API layer of the application:
  - An Amazon API Gateway REST API, configured with a Lambda proxy
    integration so all requests are forwarded to the compute stack's
    handler function.
  - Access logging to a dedicated CloudWatch Log Group.
  - Throttling limits to protect the backend from traffic spikes (a basic,
    sensible secure default).

The API's URL is exposed as a CloudFormation output for convenience after
deployment.
"""

import os

from aws_cdk import (
    Stack,
    Tags,
    CfnOutput,
    RemovalPolicy,
    aws_apigateway as apigw,
    aws_lambda as _lambda,
    aws_logs as logs,
)
from constructs import Construct


class ApiStack(Stack):
    """Creates the API Gateway REST API and wires it to the Lambda handler."""

    def __init__(
        self,
        scope: Construct,
        construct_id: str,
        handler_function: _lambda.Function,
        **kwargs,
    ) -> None:
        super().__init__(scope, construct_id, **kwargs)

        project_name = os.getenv("PROJECT_NAME", "iac-webapp")
        environment = os.getenv("DEPLOY_ENV", "dev")

        # ------------------------------------------------------------------
        # Access log group for API Gateway (separate from the Lambda's own
        # log group) so request-level access logs can be inspected
        # independently of application logs.
        # ------------------------------------------------------------------
        self.access_log_group = logs.LogGroup(
            self,
            "ApiAccessLogGroup",
            log_group_name=f"/aws/apigateway/{project_name}-{environment}-access-logs",
            retention=logs.RetentionDays.TWO_WEEKS,
            removal_policy=RemovalPolicy.DESTROY,
        )

        # ------------------------------------------------------------------
        # REST API with a Lambda proxy integration
        # ------------------------------------------------------------------
        self.api = apigw.RestApi(
            self,
            "ApplicationApi",
            rest_api_name=f"{project_name}-{environment}-api",
            description="Public REST API fronting the application Lambda "
            "function.",
            deploy_options=apigw.StageOptions(
                stage_name=environment,
                # Send structured access logs to CloudWatch.
                access_log_destination=apigw.LogGroupLogDestination(
                    self.access_log_group
                ),
                access_log_format=apigw.AccessLogFormat.json_with_standard_fields(
                    caller=True,
                    http_method=True,
                    ip=True,
                    protocol=True,
                    request_time=True,
                    resource_path=True,
                    response_length=True,
                    status=True,
                    user=True,
                ),
                logging_level=apigw.MethodLoggingLevel.INFO,
                metrics_enabled=True,
                # Basic throttling to guard against traffic spikes / abuse.
                throttling_rate_limit=50,
                throttling_burst_limit=100,
            ),
            # Restrict to REGIONAL endpoint type - avoids the extra latency
            # of the EDGE (CloudFront) type when a global CDN isn't needed.
            endpoint_types=[apigw.EndpointType.REGIONAL],
            default_cors_preflight_options=apigw.CorsOptions(
                allow_origins=apigw.Cors.ALL_ORIGINS,
                allow_methods=["GET", "POST", "OPTIONS"],
            ),
        )

        # Lambda proxy integration - forwards the full request/response
        # to/from the handler function.
        lambda_integration = apigw.LambdaIntegration(
            handler_function,
            proxy=True,
        )

        # /items resource supporting GET (list) and POST (create).
        items_resource = self.api.root.add_resource("items")
        items_resource.add_method("GET", lambda_integration)
        items_resource.add_method("POST", lambda_integration)

        # /items/{id} resource supporting GET (read one).
        item_resource = items_resource.add_resource("{id}")
        item_resource.add_method("GET", lambda_integration)

        # ------------------------------------------------------------------
        # Outputs
        # ------------------------------------------------------------------
        CfnOutput(
            self,
            "ApiEndpoint",
            value=self.api.url,
            description="Base URL of the deployed REST API",
        )

        # ------------------------------------------------------------------
        # Tagging
        # ------------------------------------------------------------------
        Tags.of(self).add("Project", project_name)
        Tags.of(self).add("Environment", environment)
        Tags.of(self).add("Stack", "ApiStack")
