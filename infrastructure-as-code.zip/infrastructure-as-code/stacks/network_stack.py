"""
network_stack.py
-----------------
Defines the networking layer of the application:
  - A VPC spanning 2 Availability Zones for high availability.
  - Public subnets (for resources that need direct internet access, e.g. NAT
    Gateways / future load balancers).
  - Private subnets with egress (for Lambda / future compute that should NOT
    be directly reachable from the internet, but still needs outbound access
    via NAT).
  - An Internet Gateway (created automatically by CDK when public subnets
    exist).
  - A single NAT Gateway (cost-optimized for a dev/intermediate project;
    production workloads would typically use one NAT Gateway per AZ).
  - Security groups following least-privilege principles.

This stack exposes its VPC and security groups as public attributes so that
other stacks (compute, storage) can consume them.
"""

import os

from aws_cdk import (
    Stack,
    Tags,
    aws_ec2 as ec2,
)
from constructs import Construct


class NetworkStack(Stack):
    """Creates the VPC and shared networking resources for the workload."""

    def __init__(self, scope: Construct, construct_id: str, **kwargs) -> None:
        super().__init__(scope, construct_id, **kwargs)

        # Read environment/project metadata from environment variables (with
        # sensible defaults) so the same code can be reused across
        # dev/stage/prod deployments without modification.
        project_name = os.getenv("PROJECT_NAME", "iac-webapp")
        environment = os.getenv("DEPLOY_ENV", "dev")
        nat_gateway_count = int(os.getenv("NAT_GATEWAY_COUNT", "1"))

        # ------------------------------------------------------------------
        # VPC
        # ------------------------------------------------------------------
        # max_azs=2 gives us high availability across two Availability Zones
        # without the extra cost of a 3rd AZ, which is a reasonable default
        # for an intermediate-level project.
        self.vpc = ec2.Vpc(
            self,
            "ApplicationVpc",
            vpc_name=f"{project_name}-{environment}-vpc",
            max_azs=2,
            nat_gateways=nat_gateway_count,
            ip_addresses=ec2.IpAddresses.cidr("10.0.0.0/16"),
            subnet_configuration=[
                # Public subnets: host the NAT Gateway(s) and, in the future,
                # any internet-facing load balancers.
                ec2.SubnetConfiguration(
                    name="Public",
                    subnet_type=ec2.SubnetType.PUBLIC,
                    cidr_mask=24,
                ),
                # Private subnets WITH egress: Lambda ENIs and any future
                # application compute live here. They can reach the
                # internet (e.g. to call third-party APIs) via the NAT
                # Gateway but are not directly reachable from the internet.
                ec2.SubnetConfiguration(
                    name="PrivateApp",
                    subnet_type=ec2.SubnetType.PRIVATE_WITH_EGRESS,
                    cidr_mask=24,
                ),
            ],
            # Enable DNS support so private resources can resolve AWS
            # service endpoints correctly.
            enable_dns_support=True,
            enable_dns_hostnames=True,
        )

        # ------------------------------------------------------------------
        # Security Groups (least privilege)
        # ------------------------------------------------------------------
        # Security group for the Lambda function(s). No inbound rules are
        # required because Lambda is invoked via the AWS control plane (API
        # Gateway -> Lambda integration), not via direct network access.
        # Outbound is restricted to HTTPS only, which is sufficient for
        # calling AWS APIs (DynamoDB, S3, CloudWatch, etc.) and any external
        # HTTPS APIs.
        self.lambda_security_group = ec2.SecurityGroup(
            self,
            "LambdaSecurityGroup",
            vpc=self.vpc,
            security_group_name=f"{project_name}-{environment}-lambda-sg",
            description="Security group for application Lambda functions "
            "(outbound HTTPS only, no inbound access).",
            allow_all_outbound=False,
        )

        # Explicitly allow only outbound HTTPS (443) traffic - least
        # privilege instead of relying on "allow all outbound".
        self.lambda_security_group.add_egress_rule(
            peer=ec2.Peer.any_ipv4(),
            connection=ec2.Port.tcp(443),
            description="Allow outbound HTTPS to AWS service endpoints",
        )

        # A general-purpose "internal" security group reserved for future
        # resources (e.g. an RDS instance or internal service) that should
        # only be reachable from within the VPC on a specific port. Included
        # here to demonstrate the least-privilege pattern; not attached to
        # any resource by default.
        self.internal_security_group = ec2.SecurityGroup(
            self,
            "InternalSecurityGroup",
            vpc=self.vpc,
            security_group_name=f"{project_name}-{environment}-internal-sg",
            description="Security group for internal-only resources; allows "
            "traffic solely from within the VPC CIDR range.",
            allow_all_outbound=False,
        )
        self.internal_security_group.add_ingress_rule(
            peer=ec2.Peer.ipv4(self.vpc.vpc_cidr_block),
            connection=ec2.Port.tcp(443),
            description="Allow HTTPS traffic only from within the VPC",
        )

        # ------------------------------------------------------------------
        # Tagging
        # ------------------------------------------------------------------
        # Apply consistent resource tags for cost tracking and ownership.
        Tags.of(self).add("Project", project_name)
        Tags.of(self).add("Environment", environment)
        Tags.of(self).add("Stack", "NetworkStack")
