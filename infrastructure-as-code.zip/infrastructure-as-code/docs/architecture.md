# Architecture Overview

## High-Level Diagram (Text Representation)

```
                                   Internet
                                       │
                                       ▼
                          ┌───────────────────────┐
                          │   Amazon API Gateway   │  (REGIONAL REST API,
                          │   /items  /items/{id}  │   access logging,
                          └───────────┬───────────┘   throttling)
                                      │ Lambda proxy integration
                                      ▼
                     ┌───────────────────────────────┐
                     │   AWS Lambda (Python 3.12)      │
                     │   handler.lambda_handler        │
                     └───────┬───────────────┬────────┘
                              │               │
                deployed in   │               │  least-privilege IAM role
             private subnets  │               │
                              ▼               ▼
     ┌───────────────────────────┐   ┌───────────────────────┐
     │   Amazon VPC                │   │  CloudWatch Logs       │
     │  ┌────────────┐              │   │  (Lambda + API GW)     │
     │  │Public Subnet│──NAT GW──►  │   └───────────────────────┘
     │  └────────────┘              │
     │  ┌────────────┐              │
     │  │Private Subnet (app)│◄─────┘  Lambda ENIs live here
     │  └────────────┘
     │        IGW attached to Public Subnet
     └───────────────────────────┘
                              │
              ┌───────────────┴────────────────┐
              ▼                                 ▼
   ┌─────────────────────┐          ┌─────────────────────────┐
   │  Amazon DynamoDB      │          │   Amazon S3 Bucket        │
   │  (Pay-Per-Request,    │          │   (versioned, SSE-S3,      │
   │   PITR, encrypted)    │          │    public access blocked)  │
   └─────────────────────┘          └─────────────────────────┘

                     ┌─────────────────────────────┐
                     │   CloudWatch Dashboard         │
                     │   (Lambda, API GW, DynamoDB     │
                     │    metrics in one view)          │
                     └─────────────────────────────┘
```

## Stack-by-Stack Breakdown

### 1. `NetworkStack` (`stacks/network_stack.py`)
Creates the foundational networking layer:
- A **VPC** (`10.0.0.0/16`) spanning **2 Availability Zones**.
- **Public subnets** — host the NAT Gateway; reachable from the internet via
  the auto-created **Internet Gateway**.
- **Private subnets with egress** — host the Lambda function's ENIs; can
  reach the internet/AWS services outbound via the **NAT Gateway**, but are
  not directly reachable from the internet.
- Two **Security Groups**:
  - `LambdaSecurityGroup`: no inbound rules; outbound restricted to HTTPS
    (443) only.
  - `InternalSecurityGroup`: reserved for future internal resources, allows
    inbound HTTPS only from within the VPC CIDR.

### 2. `StorageStack` (`stacks/storage_stack.py`)
Creates the data layer:
- **S3 bucket**: versioning enabled, SSE-S3 encryption, all public access
  blocked, SSL enforced via bucket policy.
- **DynamoDB table**: composite key (`pk`, `sk`), **Pay-Per-Request**
  billing mode, AWS-managed encryption at rest, point-in-time recovery
  enabled.

### 3. `ComputeStack` (`stacks/compute_stack.py`)
Creates the application logic layer:
- A dedicated **CloudWatch Log Group** with explicit retention (14 days by
  default), avoiding unbounded log storage costs.
- A **least-privilege IAM Role** for the Lambda function: only
  `AWSLambdaVPCAccessExecutionRole` (required for VPC ENI management) plus
  scoped `grant_*` permissions to the specific S3 bucket, DynamoDB table,
  and CloudWatch log group created above — no wildcard resource ARNs.
- The **Lambda function** itself (Python 3.12 runtime), deployed into the
  private subnets, using the `LambdaSecurityGroup`, with resource names
  injected via environment variables (`TABLE_NAME`, `BUCKET_NAME`, etc.).

### 4. `ApiStack` (`stacks/api_stack.py`)
Creates the public-facing API layer:
- A **REGIONAL REST API** in API Gateway with a Lambda proxy integration.
- Routes: `GET /items`, `POST /items`, `GET /items/{id}`.
- Structured **access logging** to a dedicated log group, throttling
  limits, and CORS support.

### 5. `MonitoringStack` (`stacks/monitoring_stack.py`)
Creates the observability layer:
- A **CloudWatch Dashboard** combining Lambda metrics (invocations, errors,
  duration, throttles), API Gateway metrics (requests, 4xx/5xx, latency),
  and DynamoDB metrics (consumed capacity, throttled requests) into a
  single operational view.

## Design Principles Applied

- **Least privilege**: IAM roles and security groups grant only the
  specific permissions/ports required; `grant_*` CDK helper methods are
  used instead of hand-written wildcard policies wherever possible.
- **Secure defaults**: S3 public access is fully blocked, SSL is enforced,
  encryption at rest is enabled everywhere, and Lambda has no direct
  inbound network exposure.
- **Modularity**: each stack has a single, clear responsibility and
  communicates with other stacks only through explicit constructor
  parameters (VPC, security group, bucket, table, function, API) — not
  global state.
- **Observability by default**: every compute/API resource ships with
  logging and metrics wired up from day one, not bolted on later.
- **Environment-driven configuration**: `PROJECT_NAME`, `DEPLOY_ENV`,
  `CDK_DEFAULT_ACCOUNT`, `CDK_DEFAULT_REGION`, `NAT_GATEWAY_COUNT`, and
  `LOG_RETENTION_DAYS` environment variables let the same code deploy
  cleanly to dev/stage/prod without modification.
